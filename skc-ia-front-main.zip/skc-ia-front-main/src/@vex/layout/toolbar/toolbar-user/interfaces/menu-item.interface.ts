export interface MenuItem {
  id: string;
  icon: string;
  label: string;
  description: string;
  colorClass: string;
  route: string;
}
