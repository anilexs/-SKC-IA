import { Injectable } from '@angular/core';
import { MapValo } from '../models/maps/map.interface';

@Injectable({
  providedIn: 'root'
})
export class MapsService {

  maps: MapValo[] = [
    {
      "uuid": "7eaecc1b-4337-bbf6-6ab9-04b8f06b3319",
      "displayName": "Ascent",
      "urlName": "ascent",
      "xMultiplier": 0.00007,
      "yMultiplier": -0.00007,
      "xScalarToAdd": 0.813895,
      "yScalarToAdd": 0.573242,
      "callouts": [
        {
          "regionName": "Tree",
          "superRegionName": "A",
          "location": {
            "x": 3980.9062,
            "y": -5938.758
          }
        },
        {
          "regionName": "Lobby",
          "superRegionName": "A",
          "location": {
            "x": 4489.032,
            "y": -3014.0515
          }
        },
        {
          "regionName": "Main",
          "superRegionName": "A",
          "location": {
            "x": 5321.6206,
            "y": -4710.1274
          }
        },
        {
          "regionName": "Window",
          "superRegionName": "A",
          "location": {
            "x": 4023.0244,
            "y": -8180.692
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "A",
          "location": {
            "x": 6153.585,
            "y": -6626.2114
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Attacker Side",
          "location": {
            "x": 60,
            "y": 50
          }
        },
        {
          "regionName": "Lobby",
          "superRegionName": "B",
          "location": {
            "x": -1490.5864,
            "y": -1389.9706
          }
        },
        {
          "regionName": "Main",
          "superRegionName": "B",
          "location": {
            "x": -1983.6713,
            "y": -5840.8125
          }
        },
        {
          "regionName": "Boat House",
          "superRegionName": "B",
          "location": {
            "x": -4484.774,
            "y": -7763.3584
          }
        },
        {
          "regionName": "Bottom",
          "superRegionName": "Mid",
          "location": {
            "x": 1122.2262,
            "y": -5951.704
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "B",
          "location": {
            "x": -2344.065,
            "y": -7548.511
          }
        },
        {
          "regionName": "Catwalk",
          "superRegionName": "Mid",
          "location": {
            "x": 2315.7944,
            "y": -4127.2554
          }
        },
        {
          "regionName": "Cubby",
          "superRegionName": "Mid",
          "location": {
            "x": 3387.3167,
            "y": -5129.764
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Defender Side",
          "location": {
            "x": 1995.2354,
            "y": -9744.923
          }
        },
        {
          "regionName": "Garden",
          "superRegionName": "A",
          "location": {
            "x": 3773.6653,
            "y": -7551.3535
          }
        },
        {
          "regionName": "Market",
          "superRegionName": "Mid",
          "location": {
            "x": 1089.1044,
            "y": -7363.1914
          }
        },
        {
          "regionName": "Courtyard",
          "superRegionName": "Mid",
          "location": {
            "x": 1222.7029,
            "y": -4586.6
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "Mid",
          "location": {
            "x": -632.0929,
            "y": -4280.2573
          }
        },
        {
          "regionName": "Pizza",
          "superRegionName": "Mid",
          "location": {
            "x": 1801.5667,
            "y": -7262.1704
          }
        },
        {
          "regionName": "Rafters",
          "superRegionName": "A",
          "location": {
            "x": 6129.893,
            "y": -8210
          }
        },
        {
          "regionName": "Top",
          "superRegionName": "Mid",
          "location": {
            "x": 2753.9297,
            "y": -2129.6155
          }
        },
        {
          "regionName": "Wine",
          "superRegionName": "A",
          "location": {
            "x": 7358.7407,
            "y": -4689.2705
          }
        }
      ]
    },
    {
      "uuid": "b529448b-4d60-346e-e89e-00a4c527a405",
      "displayName": "Fracture",
      "urlName": "fracture",
      "xMultiplier": 0.000078,
      "yMultiplier": -0.000078,
      "xScalarToAdd": 0.556952,
      "yScalarToAdd": 1.155886,
      "callouts": [
        {
          "regionName": "Bridge",
          "superRegionName": "Attacker Side",
          "location": {
            "x": 13204,
            "y": -756
          }
        },
        {
          "regionName": "Bench",
          "superRegionName": "B",
          "location": {
            "x": 11473,
            "y": -2897
          }
        },
        {
          "regionName": "Arcade",
          "superRegionName": "B",
          "location": {
            "x": 10181,
            "y": -4179
          }
        },
        {
          "regionName": "Tower",
          "superRegionName": "B",
          "location": {
            "x": 9155,
            "y": -5601
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "B",
          "location": {
            "x": 8178,
            "y": -5942
          }
        },
        {
          "regionName": "Generator",
          "superRegionName": "B",
          "location": {
            "x": 8362,
            "y": -3380
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "B",
          "location": {
            "x": 9198,
            "y": -2741
          }
        },
        {
          "regionName": "Canteen",
          "superRegionName": "B",
          "location": {
            "x": 7111,
            "y": -3138
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "A",
          "location": {
            "x": 8578,
            "y": 1302
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Defender Side",
          "location": {
            "x": 9156,
            "y": -677
          }
        },
        {
          "regionName": "Main",
          "superRegionName": "B",
          "location": {
            "x": 5967,
            "y": -5343
          }
        },
        {
          "regionName": "Tree",
          "superRegionName": "B",
          "location": {
            "x": 4965,
            "y": -4109
          }
        },
        {
          "regionName": "Tunnel",
          "superRegionName": "B",
          "location": {
            "x": 7402,
            "y": -4058
          }
        },
        {
          "regionName": "Hall",
          "superRegionName": "A",
          "location": {
            "x": 5063.5464,
            "y": 2057.6648
          }
        },
        {
          "regionName": "Door",
          "superRegionName": "A",
          "location": {
            "x": 5807.855,
            "y": 1940.4603
          }
        },
        {
          "regionName": "Rope",
          "superRegionName": "A",
          "location": {
            "x": 6638.828,
            "y": 1052.6461
          }
        },
        {
          "regionName": "Main",
          "superRegionName": "A",
          "location": {
            "x": 5878.792,
            "y": 3450.9639
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "A",
          "location": {
            "x": 8125.7627,
            "y": 3373.7861
          }
        },
        {
          "regionName": "Drop",
          "superRegionName": "A",
          "location": {
            "x": 9306.803,
            "y": 2826.1626
          }
        },
        {
          "regionName": "Dish",
          "superRegionName": "A",
          "location": {
            "x": 11296.665,
            "y": 1391.7144
          }
        },
        {
          "regionName": "Gate",
          "superRegionName": "A",
          "location": {
            "x": 12962,
            "y": 1565
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Attacker Side",
          "location": {
            "x": 4345.554,
            "y": -948.4505
          }
        }
      ]
    },
    {
      "uuid": "2c9d57ec-4431-9c5e-2939-8f9ef6dd5cba",
      "displayName": "Bind",
      "urlName": "bind",
      "xMultiplier": 0.000059,
      "yMultiplier": -0.000059,
      "xScalarToAdd": 0.576941,
      "yScalarToAdd": 0.967566,
      "callouts": [
        {
          "regionName": "Exit",
          "superRegionName": "A",
          "location": {
            "x": 5875.4106,
            "y": 4924.497
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "A",
          "location": {
            "x": 6365.635,
            "y": -1007.0208
          }
        },
        {
          "regionName": "Lobby",
          "superRegionName": "A",
          "location": {
            "x": 6113.239,
            "y": 3158.823
          }
        },
        {
          "regionName": "Short",
          "superRegionName": "A",
          "location": {
            "x": 7983.3467,
            "y": 803.96063
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "A",
          "location": {
            "x": 10747.902,
            "y": 2664.4436
          }
        },
        {
          "regionName": "Teleporter",
          "superRegionName": "A",
          "location": {
            "x": 9432.303,
            "y": 489.8803
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Attacker Side",
          "location": {
            "x": 161.64832,
            "y": 77.51108
          }
        },
        {
          "regionName": "Exit",
          "superRegionName": "B",
          "location": {
            "x": 8921.412,
            "y": -1763.2295
          }
        },
        {
          "regionName": "Hall",
          "superRegionName": "B",
          "location": {
            "x": 12981.879,
            "y": -4941.7544
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "B",
          "location": {
            "x": 6361.57,
            "y": -2621.1829
          }
        },
        {
          "regionName": "Fountain",
          "superRegionName": "B",
          "location": {
            "x": 5737.1484,
            "y": -5390.446
          }
        },
        {
          "regionName": "Long",
          "superRegionName": "B",
          "location": {
            "x": 7666.669,
            "y": -6512.8022
          }
        },
        {
          "regionName": "Short",
          "superRegionName": "B",
          "location": {
            "x": 7424.1313,
            "y": -3056.4531
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "B",
          "location": {
            "x": 11108.108,
            "y": -4831.4585
          }
        },
        {
          "regionName": "Teleporter",
          "superRegionName": "B",
          "location": {
            "x": 9027.776,
            "y": -7223.8066
          }
        },
        {
          "regionName": "Window",
          "superRegionName": "B",
          "location": {
            "x": 8826.788,
            "y": -4309.4116
          }
        },
        {
          "regionName": "Bath",
          "superRegionName": "A",
          "location": {
            "x": 9106.541,
            "y": 4449.6587
          }
        },
        {
          "regionName": "Cave",
          "superRegionName": "Attacker Side",
          "location": {
            "x": 3920.3887,
            "y": 256.94193
          }
        },
        {
          "regionName": "Cubby",
          "superRegionName": "A",
          "location": {
            "x": 8605.168,
            "y": 174.89832
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Defender Side",
          "location": {
            "x": 14641.918,
            "y": -1017.6743
          }
        },
        {
          "regionName": "Elbow",
          "superRegionName": "B",
          "location": {
            "x": 11212.901,
            "y": -7095.3335
          }
        },
        {
          "regionName": "Garden",
          "superRegionName": "B",
          "location": {
            "x": 9144.103,
            "y": -5598.1274
          }
        },
        {
          "regionName": "Lamps",
          "superRegionName": "A",
          "location": {
            "x": 10649.471,
            "y": 79.904434
          }
        },
        {
          "regionName": "Tower",
          "superRegionName": "A",
          "location": {
            "x": 12872.583,
            "y": 2556.7708
          }
        }
      ]
    },
    {
      "uuid": "2fb9a4fd-47b8-4e7d-a969-74b4046ebd53",
      "displayName": "Breeze",
      "urlName": "breeze",
      "xMultiplier": 0.00007,
      "yMultiplier": -0.00007,
      "xScalarToAdd": 0.465123,
      "yScalarToAdd": 0.833078,
      "callouts": [
        {
          "regionName": "Hall",
          "superRegionName": "A",
          "location": {
            "x": 4825,
            "y": 2550
          }
        },
        {
          "regionName": "Bridge",
          "superRegionName": "A",
          "location": {
            "x": 8400,
            "y": 3525
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Defender Side",
          "location": {
            "x": 8900,
            "y": 3525
          }
        },
        {
          "regionName": "Arches",
          "superRegionName": "Defender Side",
          "location": {
            "x": 9400,
            "y": -1300
          }
        },
        {
          "regionName": "Wood Doors",
          "superRegionName": "Mid",
          "location": {
            "x": 4825,
            "y": 2550
          }
        },
        {
          "regionName": "Pillar",
          "superRegionName": "Mid",
          "location": {
            "x": 4175,
            "y": 475
          }
        },
        {
          "regionName": "Top",
          "superRegionName": "Mid",
          "location": {
            "x": 6175,
            "y": 525
          }
        },
        {
          "regionName": "Nest",
          "superRegionName": "Mid",
          "location": {
            "x": 8650,
            "y": 275
          }
        },
        {
          "regionName": "Window",
          "superRegionName": "B",
          "location": {
            "x": 2225,
            "y": -4175
          }
        },
        {
          "regionName": "Main",
          "superRegionName": "B",
          "location": {
            "x": 3550,
            "y": -4450
          }
        },
        {
          "regionName": "Snake",
          "superRegionName": "Attacker Side",
          "location": {
            "x": 550,
            "y": -2450
          }
        },
        {
          "regionName": "Elbow",
          "superRegionName": "B",
          "location": {
            "x": 4675,
            "y": -2900
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "B",
          "location": {
            "x": 6450,
            "y": -5650
          }
        },
        {
          "regionName": "Tunnel",
          "superRegionName": "B",
          "location": {
            "x": 6450,
            "y": -1450
          }
        },
        {
          "regionName": "Stack",
          "superRegionName": "Mid",
          "location": {
            "x": 5150,
            "y": -1325
          }
        },
        {
          "regionName": "Switch",
          "superRegionName": "A",
          "location": {
            "x": 6425,
            "y": 3050
          }
        },
        {
          "regionName": "Chute",
          "superRegionName": "Mid",
          "location": {
            "x": 3875,
            "y": 1800
          }
        },
        {
          "regionName": "Back",
          "superRegionName": "B",
          "location": {
            "x": 7550,
            "y": -5675
          }
        },
        {
          "regionName": "Wall",
          "superRegionName": "B",
          "location": {
            "x": 8550,
            "y": -3000
          }
        },
        {
          "regionName": "Rope",
          "superRegionName": "A",
          "location": {
            "x": 3100,
            "y": 2550
          }
        },
        {
          "regionName": "Cannon",
          "superRegionName": "Mid",
          "location": {
            "x": 2900,
            "y": -1850
          }
        },
        {
          "regionName": "Metal Doors",
          "superRegionName": "A",
          "location": {
            "x": 6825,
            "y": 2550
          }
        },
        {
          "regionName": "Bottom",
          "superRegionName": "Mid",
          "location": {
            "x": 1575,
            "y": 475
          }
        },
        {
          "regionName": "Lobby",
          "superRegionName": "A",
          "location": {
            "x": -1250,
            "y": 3400
          }
        },
        {
          "regionName": "Cave",
          "superRegionName": "A",
          "location": {
            "x": 100,
            "y": 8375
          }
        },
        {
          "regionName": "Shop",
          "superRegionName": "A",
          "location": {
            "x": 2150,
            "y": 4250
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "A",
          "location": {
            "x": 4825,
            "y": 6325
          }
        },
        {
          "regionName": "Pyramids",
          "superRegionName": "A",
          "location": {
            "x": 5200,
            "y": 5450
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Attacker Side",
          "location": {
            "x": -575,
            "y": -450
          }
        }
      ]
    },
    {
      "uuid": "fd267378-4d1d-484f-ff52-77821ed10dc2",
      "displayName": "Pearl",
      "urlName": "pearl",
      "xMultiplier": 0.000078,
      "yMultiplier": -0.000078,
      "xScalarToAdd": 0.480469,
      "yScalarToAdd": 0.916016,
      "callouts": [
        {
          "regionName": "Hall",
          "superRegionName": "B",
          "location": {
            "x": 7598.2993,
            "y": -4751.088
          }
        },
        {
          "regionName": "Doors",
          "superRegionName": "Mid",
          "location": {
            "x": 4701.24,
            "y": 597.23285
          }
        },
        {
          "regionName": "Connector",
          "superRegionName": "Mid",
          "location": {
            "x": 6047.0464,
            "y": 1800.0436
          }
        },
        {
          "regionName": "Water",
          "superRegionName": "Defender Side",
          "location": {
            "x": 7808.019,
            "y": 1800.0419
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Defender Side",
          "location": {
            "x": 11092.458,
            "y": 378.79883
          }
        },
        {
          "regionName": "Flowers",
          "superRegionName": "A",
          "location": {
            "x": 9263.969,
            "y": 2507.3403
          }
        },
        {
          "regionName": "Secret",
          "superRegionName": "A",
          "location": {
            "x": 10458.144,
            "y": 3831.5127
          }
        },
        {
          "regionName": "Dugout",
          "superRegionName": "A",
          "location": {
            "x": 7660.6597,
            "y": 5854.0664
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "A",
          "location": {
            "x": 6613.846,
            "y": 5569.5254
          }
        },
        {
          "regionName": "Records",
          "superRegionName": "Defender Side",
          "location": {
            "x": 8973.152,
            "y": -1470.2677
          }
        },
        {
          "regionName": "Top",
          "superRegionName": "Mid",
          "location": {
            "x": 2075,
            "y": 725
          }
        },
        {
          "regionName": "Tunnel",
          "superRegionName": "B",
          "location": {
            "x": 8973.152,
            "y": -2155.1323
          }
        },
        {
          "regionName": "Tower",
          "superRegionName": "B",
          "location": {
            "x": 8533.423,
            "y": -2851.3516
          }
        },
        {
          "regionName": "Main",
          "superRegionName": "A",
          "location": {
            "x": 6368.5713,
            "y": 3825
          }
        },
        {
          "regionName": "Restaurant",
          "superRegionName": "A",
          "location": {
            "x": 4430.452,
            "y": 2813.1267
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "B",
          "location": {
            "x": 4503.3633,
            "y": -591.64435
          }
        },
        {
          "regionName": "Art",
          "superRegionName": "A",
          "location": {
            "x": 4561.95,
            "y": 3406.8806
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "A",
          "location": {
            "x": 6055.2104,
            "y": 3782.704
          }
        },
        {
          "regionName": "Plaza",
          "superRegionName": "Mid",
          "location": {
            "x": 2750,
            "y": -325
          }
        },
        {
          "regionName": "Shops",
          "superRegionName": "Mid",
          "location": {
            "x": 800,
            "y": -1450
          }
        },
        {
          "regionName": "Club",
          "superRegionName": "B",
          "location": {
            "x": 800,
            "y": -1450
          }
        },
        {
          "regionName": "Ramp",
          "superRegionName": "B",
          "location": {
            "x": 1750,
            "y": -3800
          }
        },
        {
          "regionName": "Main",
          "superRegionName": "B",
          "location": {
            "x": 4050,
            "y": -4375
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "B",
          "location": {
            "x": 5800,
            "y": -2850
          }
        },
        {
          "regionName": "Screen",
          "superRegionName": "B",
          "location": {
            "x": 6401.025,
            "y": -5191.47
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Attacker Side",
          "location": {
            "x": -550,
            "y": -600
          }
        }
      ]
    },
    {
      "uuid": "e2ad5c54-4114-a870-9641-8ea21279579a",
      "displayName": "Icebox",
      "urlName": "icebox",
      "xMultiplier": 0.000072,
      "yMultiplier": -0.000072,
      "xScalarToAdd": 0.460214,
      "yScalarToAdd": 0.304687,
      "callouts": [
        {
          "regionName": "Garage",
          "superRegionName": "B",
          "location": {
            "x": -1250,
            "y": -1425
          }
        },
        {
          "regionName": "Belt",
          "superRegionName": "A",
          "location": {
            "x": -7200,
            "y": -850
          }
        },
        {
          "regionName": "Nest",
          "superRegionName": "A",
          "location": {
            "x": -6650,
            "y": 900
          }
        },
        {
          "regionName": "Pipes",
          "superRegionName": "A",
          "location": {
            "x": -6150,
            "y": 450
          }
        },
        {
          "regionName": "Rafters",
          "superRegionName": "A",
          "location": {
            "x": -6450,
            "y": 4250
          }
        },
        {
          "regionName": "Screen",
          "superRegionName": "A",
          "location": {
            "x": -5100,
            "y": 3325
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "A",
          "location": {
            "x": -6400,
            "y": 3200
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Attacker Side",
          "location": {
            "x": -3925,
            "y": -4450
          }
        },
        {
          "regionName": "Yellow",
          "superRegionName": "B",
          "location": {
            "x": 2050,
            "y": -25
          }
        },
        {
          "regionName": "Back",
          "superRegionName": "B",
          "location": {
            "x": 251,
            "y": 4269
          }
        },
        {
          "regionName": "Fence",
          "superRegionName": "B",
          "location": {
            "x": 251.00003,
            "y": 3236.0525
          }
        },
        {
          "regionName": "Cubby",
          "superRegionName": "B",
          "location": {
            "x": 1050,
            "y": -975
          }
        },
        {
          "regionName": "Green",
          "superRegionName": "B",
          "location": {
            "x": -450,
            "y": -700
          }
        },
        {
          "regionName": "Hall",
          "superRegionName": "B",
          "location": {
            "x": 300,
            "y": 3050
          }
        },
        {
          "regionName": "Hut",
          "superRegionName": "B",
          "location": {
            "x": -1425,
            "y": 4400
          }
        },
        {
          "regionName": "Kitchen",
          "superRegionName": "B",
          "location": {
            "x": -2221.3618,
            "y": 3403.649
          }
        },
        {
          "regionName": "Orange",
          "superRegionName": "B",
          "location": {
            "x": -632,
            "y": 1700
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "B",
          "location": {
            "x": 1725,
            "y": 2575
          }
        },
        {
          "regionName": "Snowman",
          "superRegionName": "B",
          "location": {
            "x": 2250,
            "y": 3960.3218
          }
        },
        {
          "regionName": "Snow Pile",
          "superRegionName": "B",
          "location": {
            "x": -1775,
            "y": 2500
          }
        },
        {
          "regionName": "Tube",
          "superRegionName": "B",
          "location": {
            "x": -2300,
            "y": 1275
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Defender Side",
          "location": {
            "x": -3750,
            "y": 7075
          }
        },
        {
          "regionName": "Blue",
          "superRegionName": "Mid",
          "location": {
            "x": -2825,
            "y": 975
          }
        },
        {
          "regionName": "Boiler",
          "superRegionName": "Mid",
          "location": {
            "x": -3375,
            "y": 2925
          }
        },
        {
          "regionName": "Pallet",
          "superRegionName": "Mid",
          "location": {
            "x": -4450,
            "y": 1775
          }
        },
        {
          "regionName": "Fence",
          "superRegionName": "B",
          "location": {
            "x": 363,
            "y": 3595
          }
        }
      ]
    },
    {
      "uuid": "2bee0dc9-4ffe-519b-1cbd-7fbe763a6047",
      "displayName": "Haven",
      "urlName": "haven",
      "xMultiplier": 0.000075,
      "yMultiplier": -0.000075,
      "xScalarToAdd": 1.09345,
      "yScalarToAdd": 0.642728,
      "callouts": [
        {
          "regionName": "Garden",
          "superRegionName": "A",
          "location": {
            "x": 3100.261,
            "y": -4683.6016
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "A",
          "location": {
            "x": 4244.4214,
            "y": -10715.68
          }
        },
        {
          "regionName": "Lobby",
          "superRegionName": "A",
          "location": {
            "x": 3438.537,
            "y": -6260.409
          }
        },
        {
          "regionName": "Long",
          "superRegionName": "A",
          "location": {
            "x": 6209.695,
            "y": -6901.142
          }
        },
        {
          "regionName": "Sewer",
          "superRegionName": "A",
          "location": {
            "x": 3452.8735,
            "y": -7915.7246
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "A",
          "location": {
            "x": 6309.3076,
            "y": -9225.703
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Attacker Side",
          "location": {
            "x": 1741.7622,
            "y": -2642.7925
          }
        },
        {
          "regionName": "Back",
          "superRegionName": "B",
          "location": {
            "x": 1966.1608,
            "y": -10664.775
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "B",
          "location": {
            "x": 1884.706,
            "y": -9231.335
          }
        },
        {
          "regionName": "Link",
          "superRegionName": "C",
          "location": {
            "x": -87.761444,
            "y": -10004.415
          }
        },
        {
          "regionName": "Lobby",
          "superRegionName": "C",
          "location": {
            "x": -1642.189,
            "y": -5720.345
          }
        },
        {
          "regionName": "Long",
          "superRegionName": "C",
          "location": {
            "x": -3356.814,
            "y": -5990.872
          }
        },
        {
          "regionName": "Garage",
          "superRegionName": "C",
          "location": {
            "x": 180.07678,
            "y": -7999.5845
          }
        },
        {
          "regionName": "Window",
          "superRegionName": "C",
          "location": {
            "x": -10.126678,
            "y": -8993.241
          }
        },
        {
          "regionName": "Site",
          "superRegionName": "C",
          "location": {
            "x": -2378.1328,
            "y": -9010.557
          }
        },
        {
          "regionName": "Cubby",
          "superRegionName": "C",
          "location": {
            "x": -2119.7693,
            "y": -6561.603
          }
        },
        {
          "regionName": "Spawn",
          "superRegionName": "Defender Side",
          "location": {
            "x": 2946.3042,
            "y": -12714.707
          }
        },
        {
          "regionName": "Doors",
          "superRegionName": "Mid",
          "location": {
            "x": 151.11594,
            "y": -6262.9155
          }
        },
        {
          "regionName": "Courtyard",
          "superRegionName": "Mid",
          "location": {
            "x": 1822.1299,
            "y": -6712.6875
          }
        },
        {
          "regionName": "Window",
          "superRegionName": "Mid",
          "location": {
            "x": 1950.2218,
            "y": -5567.912
          }
        },
        {
          "regionName": "Tower",
          "superRegionName": "A",
          "location": {
            "x": 6721.4043,
            "y": -10472.5205
          }
        }
      ]
    }
  ];

  constructor() { }
}
