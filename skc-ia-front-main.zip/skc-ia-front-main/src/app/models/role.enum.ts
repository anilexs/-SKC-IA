export enum Role {
    admin = "Administrateur",
    fondateur = "Fondateur",
    coach = "Coach",
    membre = "Membre",
    invite = "Invité"
}