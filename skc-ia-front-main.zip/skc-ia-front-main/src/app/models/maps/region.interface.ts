export interface RegionMapValo {
    location: {
        x: number,
        y: number
    };
    regionName: string;
    superRegionName: string;
}